//
//  Building.m
//  RESideMenuStoryboardsExample
//
//  Created by shashibici on 12/3/14.
//  Copyright (c) 2014 Roman Efimov. All rights reserved.
//

#import "Building.h"

@implementation Building





@end

//
//  GlobalData.h
//  RESideMenuStoryboardsExample
//
//  Created by ChenYirui on 12/7/14.
//  Copyright (c) 2014 Roman Efimov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GlobalData : NSObject

+(double) lat;
+(void) setLat:(double)la;

+(double) lon;
+(void) setLon:(double)lo;

@end
